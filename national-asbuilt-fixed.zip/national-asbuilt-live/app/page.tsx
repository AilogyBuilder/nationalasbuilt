import { Hero } from "@/components/Hero";
import { StatsStrip } from "@/components/StatsStrip";
import { ServicesGrid } from "@/components/ServicesGrid";
import { Process } from "@/components/Process";
import { Proof } from "@/components/Proof";
import { Pricing } from "@/components/Pricing";
import { QuoteCalculator } from "@/components/QuoteCalculator";
import { LeadForm } from "@/components/LeadForm";
import { CitiesGrid } from "@/components/CitiesGrid";
import { EnterpriseFunnel } from "@/components/EnterpriseFunnel";
import { CtaBand } from "@/components/CtaBand";
import { Section } from "@/components/Section";

export default function HomePage() {
  return (
    <>
      <Hero />
      <StatsStrip />
      <ServicesGrid />
      <Process />
      <Proof />
      <Pricing />
      <Section
        eyebrow="Estimate your project"
        title="Instant quote calculator"
        subtitle="Enter your project details and get an estimated cost range before you reach out."
      >
        <div className="grid gap-6">
          <QuoteCalculator />
        </div>
      </Section>
      <Section
        id="quote"
        eyebrow="Get started"
        title="Request a quote"
        subtitle="Tell us about your project and a team member will follow up promptly to discuss scope, timeline, and pricing."
        className="bg-slate-50"
      >
        <div className="grid gap-6 lg:grid-cols-[1.1fr_0.9fr]">
          <LeadForm />
          <div className="card">
            <h3 className="text-xl font-semibold text-slate-950">What to expect</h3>
            <p className="mt-3 text-slate-600 leading-7">We respond to every quote request promptly. Here is what happens after you submit:</p>
            <ul className="mt-4 space-y-3 text-slate-600 leading-7">
              <li><span className="font-medium text-slate-900">1. Quick review.</span> We look at your project type, location, and square footage to confirm scope.</li>
              <li><span className="font-medium text-slate-900">2. Follow-up call or email.</span> A team member reaches out to discuss pricing, timeline, and any specific requirements.</li>
              <li><span className="font-medium text-slate-900">3. Survey scheduled.</span> Once confirmed, we schedule your on-site survey within 48 hours.</li>
              <li><span className="font-medium text-slate-900">4. Drawings delivered.</span> Clean DWG and PDF files sent via Dropbox, ready to use immediately.</li>
            </ul>
            <p className="mt-6 text-sm text-slate-500">Prefer to reach us directly? Call <a href="tel:9723427070" className="font-medium text-slate-700">972-342-7070</a> or email <a href="mailto:info@nationalasbuilt.com" className="font-medium text-slate-700">info@nationalasbuilt.com</a>.</p>
          </div>
        </div>
      </Section>
      <CitiesGrid />
      <EnterpriseFunnel />
      <CtaBand />
    </>
  );
}
