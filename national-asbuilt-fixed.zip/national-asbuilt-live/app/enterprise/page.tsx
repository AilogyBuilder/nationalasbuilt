import { LeadForm } from "@/components/LeadForm";
import { Section } from "@/components/Section";
import { enterpriseFunnelSteps } from "@/lib/site";

export const metadata = {
  title: "Enterprise Rollout Programs | National As Built Inc.",
  description: "Standardized as-built surveys for retail chains, franchise operators, developers, and multi-site portfolios. Dedicated PM, consistent deliverables, nationwide coverage.",
};

export default function EnterprisePage() {
  return (
    <>
      <section className="border-b border-slate-200 bg-gradient-to-b from-slate-950 to-slate-900 text-white">
        <div className="container-shell py-20">
          <div className="eyebrow border-white/20 bg-white/10 text-brand-100">Multi-site programs</div>
          <h1 className="mt-6 text-5xl font-semibold tracking-tight">
            As-built surveys for portfolios, rollouts, and multi-location operations
          </h1>
          <p className="mt-6 max-w-3xl text-xl leading-8 text-slate-300">
            Retail chains, franchise operators, commercial developers, and property managers trust National As Built to deliver consistent, standardized drawings across every location in their portfolio.
          </p>
        </div>
      </section>

      <Section
        eyebrow="Our process"
        title="How enterprise programs work"
        subtitle="We handle documentation at scale so your teams can focus on design and construction, not chasing field data."
      >
        <div className="grid gap-6 lg:grid-cols-4">
          {enterpriseFunnelSteps.map((step) => (
            <div key={step.title} className="card">
              <h2 className="text-lg font-semibold">{step.title}</h2>
              <p className="mt-3 text-slate-600 leading-7">{step.description}</p>
            </div>
          ))}
        </div>
      </Section>

      <Section
        eyebrow="Who we work with"
        title="Built for organizations managing multiple locations"
        subtitle="Inconsistent documentation slows down every project downstream. Our standardized programs fix that."
        className="bg-slate-50"
      >
        <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-4">
          {[
            { name: "Retail chains", description: "Standardized floor plans and Scan-to-CAD across every store location, delivered to a consistent template." },
            { name: "Hospitality brands", description: "Accurate existing-conditions documentation for renovation, brand refresh, and compliance projects." },
            { name: "Office portfolios", description: "Lease area verification, space planning support, and as-built updates across your entire building portfolio." },
            { name: "Developers & design firms", description: "A reliable nationwide survey partner that integrates into your existing project workflow and delivery standards." },
          ].map((segment) => (
            <div key={segment.name} className="card">
              <h3 className="text-xl font-semibold text-slate-950">{segment.name}</h3>
              <p className="mt-3 text-slate-600 leading-7">{segment.description}</p>
            </div>
          ))}
        </div>
      </Section>

      <Section
        eyebrow="Request a proposal"
        title="Start with a conversation"
        subtitle="Tell us about your portfolio or rollout and we will put together a program that fits your scope, timeline, and standards."
      >
        <div className="grid gap-6 lg:grid-cols-[1fr_0.9fr]">
          <LeadForm source="enterprise" page="/enterprise" compact />
          <div className="card">
            <h3 className="text-xl font-semibold text-slate-950">What enterprise clients get</h3>
            <ul className="mt-4 space-y-3 text-slate-600 leading-7">
              <li><span className="font-medium text-slate-900">Dedicated project manager.</span> One point of contact across all your locations, from scheduling through final delivery.</li>
              <li><span className="font-medium text-slate-900">Standardized deliverables.</span> Every drawing follows the same template, naming convention, and file structure your team expects.</li>
              <li><span className="font-medium text-slate-900">Portfolio scheduling.</span> We coordinate multi-site rollouts to match your construction or renovation calendar.</li>
              <li><span className="font-medium text-slate-900">Pilot site option.</span> Start with one location to validate quality and workflow before scaling to your full portfolio.</li>
            </ul>
            <p className="mt-6 text-sm text-slate-500">Ready to talk now? Call <a href="tel:9723427070" className="font-medium text-slate-700">972-342-7070</a> or email <a href="mailto:info@nationalasbuilt.com" className="font-medium text-slate-700">info@nationalasbuilt.com</a>.</p>
          </div>
        </div>
      </Section>
    </>
  );
}
